#include <stdio.h>

int main()
{
        printf("Hola món\n");
        return 0;
}